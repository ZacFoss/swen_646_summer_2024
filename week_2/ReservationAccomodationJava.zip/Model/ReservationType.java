
/**
 * 
 */
public enum ReservationType {
    HOTEL,
    CABIN,
    HOUSE
}