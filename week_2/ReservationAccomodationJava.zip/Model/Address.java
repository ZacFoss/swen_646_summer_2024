
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Address {

    /**
     * Default constructor
     */
    public Address() {
    }

    /**
     * 
     */
    public String street;

    /**
     * 
     */
    public String city;

    /**
     * 
     */
    public String state;

    /**
     * 
     */
    public String zipcode;

    /**
     * 
     */
    public void toString() {
        // TODO implement here
    }

    /**
     * 
     */
    public void createNewAddress() {
        // TODO implement here
    }

}