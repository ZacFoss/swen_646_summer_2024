
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Cabin {

    /**
     * Default constructor
     */
    public Cabin() {
    }

    /**
     * 
     */
    public boolean fullKitchen;

    /**
     * 
     */
    public boolean loft;

    /**
     * 
     */
    public void toString() {
        // TODO implement here
    }

}