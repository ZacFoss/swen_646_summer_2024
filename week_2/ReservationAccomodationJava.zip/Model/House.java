
import java.io.*;
import java.util.*;

/**
 * 
 */
public class House {

    /**
     * Default constructor
     */
    public House() {
    }

    /**
     * 
     */
    public int numberOfFloors;

    /**
     * 
     */
    public void toString() {
        // TODO implement here
    }

}