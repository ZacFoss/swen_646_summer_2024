
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Manager {

    /**
     * Default constructor
     */
    public Manager() {
    }

    /**
     * 
     */
    public List<Account> accounts;

    /**
     * 
     */
    public List<Reservation> reservations;

    /**
     * @param accountId
     */
    public void retrieveAllReservations(String accountId) {
        // TODO implement here
    }

    /**
     * @param account
     */
    public void addAccount(Account account) {
        // TODO implement here
    }

    /**
     * @param accountNumber
     */
    public void retrieveAccount(String accountNumber) {
        // TODO implement here
    }

    /**
     * @param accountNumber
     */
    public void updateAccount(String accountNumber) {
        // TODO implement here
    }

    /**
     * @param reservationNumber
     */
    public void completeReservation(String reservationNumber) {
        // TODO implement here
    }

    /**
     * @param reservationNumber
     */
    public void cancelReservation(String reservationNumber) {
        // TODO implement here
    }

}