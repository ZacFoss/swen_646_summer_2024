
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Account {

    /**
     * Default constructor
     */
    public Account() {
    }

    /**
     * 
     */
    public Address mailingAddress;

    /**
     * 
     */
    public List<Reservations> accountReservations;

    /**
     * 
     */
    public String accountId;

    /**
     * 
     */
    public String email;

    /**
     * 
     */
    public String phoneNumber;

    /**
     * @param accountId 
     * @param mailingAddress 
     * @param email 
     * @param phoneNumber
     */
    public void createNewAccount(String accountId, String mailingAddress, String email, String phoneNumber) {
        // TODO implement here
    }

    /**
     * 
     */
    public void addReservation() {
        // TODO implement here
    }

    /**
     * 
     */
    public void toString() {
        // TODO implement here
    }

}