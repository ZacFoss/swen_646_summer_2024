
import java.io.*;
import java.util.*;

/**
 * 
 */
public class Hotel {

    /**
     * Default constructor
     */
    public Hotel() {
    }

    /**
     * 
     */
    public boolean kitchenette;

    /**
     * 
     */
    public void toString() {
        // TODO implement here
    }

}